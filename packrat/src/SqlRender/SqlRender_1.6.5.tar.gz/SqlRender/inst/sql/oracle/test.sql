SELECT a FROM table;
