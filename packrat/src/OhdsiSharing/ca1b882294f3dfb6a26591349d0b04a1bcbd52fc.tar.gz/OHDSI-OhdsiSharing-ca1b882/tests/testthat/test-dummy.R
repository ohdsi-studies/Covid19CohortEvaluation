library("testthat")


# a test that will pass
test_that("An easy test", {
  expect_true(TRUE)
})
