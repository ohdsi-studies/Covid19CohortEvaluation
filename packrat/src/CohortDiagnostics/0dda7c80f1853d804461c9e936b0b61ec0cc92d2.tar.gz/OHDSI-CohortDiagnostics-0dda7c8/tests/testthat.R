library(testthat)
test_check("DatabaseConnector")
