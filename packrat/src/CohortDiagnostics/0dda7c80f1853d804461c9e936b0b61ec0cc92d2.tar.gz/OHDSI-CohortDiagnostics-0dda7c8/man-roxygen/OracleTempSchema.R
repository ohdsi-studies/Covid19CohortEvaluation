#' @param oracleTempSchema   Should be used in Oracle to specify a schema where the user has write
#'                           privileges for storing temporary tables.
